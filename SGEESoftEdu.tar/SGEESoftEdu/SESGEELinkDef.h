// =============================================================================
// SGEE SoftEdu - Stern-Gerlach Experiment Experience (Installer Script)
// =============================================================================
//
// Copyright (C) 2026
//
// Authors:
//   [1] Julián Salamanca*
//   [2] Diego Julián Rodríguez-Patarroyo**
//
//   [1] jasalamanca@udistrital.edu.co (profesor Universidad Distrital)
//   [2] djrodriguezp@udistrital.edu.co (profesor Universidad Distrital)
//
//  * Grupo de Física e Informática (FISINFOR)
//  ** Grupo de Laboratorio de Fuentes Alternas de Energía (LIFAE)
//  *,** Universidad Distrital Francisco José de Caldas (Bogotá, Colombia)
//  
// Web page: https://github.com/fisinforgh/sgee
//
// LICENSE: GNU General Public License v3.0 (GPLv3) or later
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// =============================================================================
#ifdef __CLING__
#pragma link C++ class SGIntegratedGUI+;
#endif
